#!/bin/bash

mkdir MyDirectory && touch MyDirectory/MyFile.txt && ls -la MyDirectory/
