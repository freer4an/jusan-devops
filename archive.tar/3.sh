#!/bin/sh

keyword=$1

grep -rl "$keyword"
